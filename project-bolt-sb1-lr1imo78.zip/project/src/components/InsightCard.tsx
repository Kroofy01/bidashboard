import React, { useState } from 'react';
import { MessageCircle, TrendingUp, Volume2 } from 'lucide-react';
import type { Insight } from '../types';

interface InsightCardProps {
  insight: Insight;
  onAddAnnotation: (id: string, text: string) => void;
}

const InsightCard: React.FC<InsightCardProps> = ({ insight, onAddAnnotation }) => {
  const [annotationText, setAnnotationText] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);

  const handleAddAnnotation = () => {
    if (annotationText.trim()) {
      onAddAnnotation(insight.id, annotationText);
      setAnnotationText('');
    }
  };

  const readInsight = () => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(
        `${insight.title}. ${insight.summary}`
      );
      utterance.rate = 1.1;
      speechSynthesis.speak(utterance);
    }
  };

  const impactColors = {
    High: 'bg-gradient-to-r from-red-500 to-pink-500 text-white',
    Medium: 'bg-gradient-to-r from-yellow-400 to-orange-500 text-white',
    Low: 'bg-gradient-to-r from-green-400 to-emerald-500 text-white'
  };

  return (
    <div className="glass-effect rounded-xl shadow-xl hover-scale rgb-glow">
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-xl font-bold text-gray-800">{insight.title}</h3>
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${impactColors[insight.impact]}`}>
            {insight.impact}
          </span>
        </div>

        <p className="text-gray-700 mb-4">{insight.summary}</p>

        <div className="flex gap-3 mb-4">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/50 hover:bg-white/80 transition-all duration-300"
          >
            <MessageCircle size={18} />
            {insight.annotations.length} Comments
          </button>
          <button
            onClick={readInsight}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/50 hover:bg-white/80 transition-all duration-300"
          >
            <Volume2 size={18} />
            Read Aloud
          </button>
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/50 hover:bg-white/80 transition-all duration-300">
            <TrendingUp size={18} />
            Analyze
          </button>
        </div>

        {isExpanded && (
          <div className="mt-6 space-y-4">
            <div className="space-y-3">
              {insight.annotations.map((note, index) => (
                <div key={index} className="bg-white/40 p-4 rounded-lg backdrop-blur-sm">
                  <div className="flex justify-between text-sm">
                    <span className="font-semibold text-gray-800">{note.author}</span>
                    <span className="text-gray-600">
                      {new Date(note.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-gray-700 mt-2">{note.text}</p>
                </div>
              ))}
            </div>

            <div className="flex gap-2 mt-4">
              <input
                type="text"
                value={annotationText}
                onChange={(e) => setAnnotationText(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleAddAnnotation()}
                placeholder="Add a comment..."
                className="flex-1 px-4 py-2 rounded-lg border-2 border-indigo-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 bg-white/70 backdrop-blur-sm transition-all duration-300"
              />
              <button
                onClick={handleAddAnnotation}
                className="px-6 py-2 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-lg hover:shadow-lg transition-all duration-300"
              >
                Add
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default InsightCard;