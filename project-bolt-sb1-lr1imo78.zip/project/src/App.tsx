import React, { useState, useEffect } from 'react';
import { LayoutGrid, List, Sparkles } from 'lucide-react';
import InsightCard from './components/InsightCard';
import { generateMockInsights } from './data/mockData';
import type { Insight } from './types';

function App() {
  const [insights, setInsights] = useState<Insight[]>([]);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  useEffect(() => {
    setInsights(generateMockInsights());
  }, []);

  const handleAddAnnotation = (insightId: string, text: string) => {
    setInsights(prevInsights => prevInsights.map(insight => {
      if (insight.id === insightId) {
        return {
          ...insight,
          annotations: [
            ...insight.annotations,
            {
              text,
              author: 'You',
              timestamp: new Date().toISOString()
            }
          ]
        };
      }
      return insight;
    }));
  };

  return (
    <div className="min-h-screen gradient-bg">
      <header className="glass-effect sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              <Sparkles className="h-8 w-8 text-indigo-500 animate-pulse" />
              <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-indigo-500">
                Insights Dashboard
              </h1>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-3 rounded-lg transition-all duration-300 ${
                  viewMode === 'grid' 
                    ? 'bg-indigo-500 text-white shadow-lg' 
                    : 'glass-effect hover:bg-indigo-100'
                }`}
              >
                <LayoutGrid size={22} />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-3 rounded-lg transition-all duration-300 ${
                  viewMode === 'list' 
                    ? 'bg-indigo-500 text-white shadow-lg' 
                    : 'glass-effect hover:bg-indigo-100'
                }`}
              >
                <List size={22} />
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div 
          className={`grid gap-6 ${
            viewMode === 'grid' 
              ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' 
              : 'grid-cols-1 max-w-3xl mx-auto'
          }`}
        >
          {insights.map(insight => (
            <InsightCard
              key={insight.id}
              insight={insight}
              onAddAnnotation={handleAddAnnotation}
            />
          ))}
        </div>
      </main>
    </div>
  );
}

export default App;