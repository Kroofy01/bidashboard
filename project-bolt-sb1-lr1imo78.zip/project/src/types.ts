export interface Insight {
  id: string;
  title: string;
  summary: string;
  impact: 'High' | 'Medium' | 'Low';
  data: number[];
  explanation?: string;
  annotations: Annotation[];
}

export interface Annotation {
  text: string;
  author: string;
  timestamp: string;
}