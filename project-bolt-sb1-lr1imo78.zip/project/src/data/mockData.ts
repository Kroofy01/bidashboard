import { faker } from '@faker-js/faker';
import { Insight } from '../types';

export const generateMockInsights = (): Insight[] => {
  return Array.from({ length: 6 }, (_, i) => ({
    id: faker.string.uuid(),
    title: faker.company.catchPhrase(),
    summary: faker.company.buzzPhrase(),
    impact: faker.helpers.arrayElement(['High', 'Medium', 'Low'] as const),
    data: Array.from({ length: 7 }, () => faker.number.int({ min: 10, max: 100 })),
    annotations: Array.from({ length: faker.number.int({ min: 0, max: 3 })}, () => ({
      text: faker.lorem.sentence(),
      author: faker.person.firstName(),
      timestamp: faker.date.recent().toISOString()
    }))
  }));
};